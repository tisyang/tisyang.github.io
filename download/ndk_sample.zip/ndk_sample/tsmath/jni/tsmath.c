#include "tsmath.h"
#include <stddef.h>
#include <jni.h>

#include "algorithm.h"



/* ------------------------------------------------------------- */
/* 方法注册资源表 */
static JNINativeMethod native_methods[] = {
    {"getVersion", "()Ljava/lang/String;", (void *)native_get_version},
    {"calcCenter", "(Lcom/zhdgps/ts/TSCoord;Lcom/zhdgps/ts/TSCoord;)Lcom/zhdgps/ts/TSCoord;", (void *)native_calc_center},
};
#define NATIVE_METHODS_COUNT (sizeof(native_methods)/sizeof(native_methods[0]))

/* 为某一个类注册方法 */
static int register_navtive_methods(JNIEnv *env,
                                    const char *classname,
                                    JNINativeMethod *methods,
                                    int methods_num)
{
    jclass clazz;
    clazz = (*env)->FindClass(env, classname);
    if(clazz == NULL) {
        return JNI_FALSE;
    }

    if((*env)->RegisterNatives(env, clazz, methods, methods_num) < 0) {
        return JNI_FALSE;
    }

    return JNI_TRUE;
}

/* 为所有类注册本地方法 */
static int register_natives(JNIEnv *env)
{
    /* 指定要注册的类名 */
    const char *classname = "com/zhdgps/ts/TSMath";
    return register_navtive_methods(env, classname, native_methods, NATIVE_METHODS_COUNT);
}
/* -------------------------------------------- */

static int helper_init_tscoord_jniinfo(JNIEnv *env);

/* System.loadLibrary 时调用，成功返回 JNI 版本，失败返回 -1
 *
 * 可在此函数中进行初始化等操作
 * */
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved)
{
    JNIEnv *env = NULL;
    jint result = -1;

    if((*vm)->GetEnv(vm, (void **)&env, JNI_VERSION_1_4) != JNI_OK) {
        D_LOG("Get env failed!");
        return -1;
    }

    if(register_natives(env) != JNI_TRUE) {
        D_LOG("Register failed!");
        return -1;
    }

    /* 填充TSCoord JNI Info */
    helper_init_tscoord_jniinfo(env);
    D_LOG("Init TSCoord succ!");

    result = JNI_VERSION_1_4;
    return result;
}

/* -------------------------------------------------------------------- */

#define TSMATH_VERSION  "v0.1 alpha"

JNIEXPORT jstring JNICALL native_get_version(JNIEnv *env, jobject thiz)
{
    return (*env)->NewStringUTF(env, TSMATH_VERSION);
}

/* 保存全局 TSCoord 的信息，便于后续检索成员 */
struct TSCoordJNIInfo {
    /* ICS 4.0 之后，jclass 可能会变化，所以在获取后，调用 NewGlobalRef 保存引用，然后就不再变化 */
    jclass cls;
    /* ID 一般不会变化 */
    jfieldID fid_n;
    jfieldID fid_e;
    jfieldID fid_z;
    jmethodID mid_init;
} g_tscoord_jni;

static int helper_init_tscoord_jniinfo(JNIEnv *env)
{
    jclass cls = (*env)->FindClass(env, "com/zhdgps/ts/TSCoord");
    jfieldID fid_n = (*env)->GetFieldID(env, cls, "N", "D");
    jfieldID fid_e = (*env)->GetFieldID(env, cls, "E", "D");
    jfieldID fid_z = (*env)->GetFieldID(env, cls, "Z", "D");
    jmethodID mid_init = (*env)->GetMethodID(env, cls, "<init>", "()V");

    /* ICS 4.0 之后保存全局引用需要调用此函数，后续需要解除引用，使用函数 DeleteGlobalRef */
    cls = (jclass)((*env)->NewGlobalRef(env, cls));
    g_tscoord_jni.cls = cls;
    g_tscoord_jni.fid_n = fid_n;
    g_tscoord_jni.fid_e = fid_e;
    g_tscoord_jni.fid_z = fid_z;
    g_tscoord_jni.mid_init = mid_init;

    return 0;
}

static jobject helper_new_tscoord(JNIEnv *env)
{
    jobject tscoord = (*env)->NewObject(env, g_tscoord_jni.cls, g_tscoord_jni.mid_init);
    return tscoord;
}

static TSCoord helper_get_tscoord(JNIEnv *env, jobject coord)
{
    TSCoord res_coord;

    jdouble n = (*env)->GetDoubleField(env, coord, g_tscoord_jni.fid_n);
    jdouble e = (*env)->GetDoubleField(env, coord, g_tscoord_jni.fid_e);
    jdouble z = (*env)->GetDoubleField(env, coord, g_tscoord_jni.fid_z);

    res_coord.N = n;
    res_coord.E = e;
    res_coord.Z = z;

    return res_coord;
}

static void helper_set_tscoord(JNIEnv *env, jobject coord, const TSCoord *source)
{
    (*env)->SetDoubleField(env, coord, g_tscoord_jni.fid_n, source->N);
    (*env)->SetDoubleField(env, coord, g_tscoord_jni.fid_e, source->E);
    (*env)->SetDoubleField(env, coord, g_tscoord_jni.fid_z, source->Z);
}

JNIEXPORT jobject JNICALL native_calc_center(JNIEnv *env, jobject thiz, jobject coorda, jobject coordb)
{
    TSCoord a, b, c;
    jobject obj;

    D_LOG("Enter calc center!");

    a = helper_get_tscoord(env, coorda);
    D_LOG("Get coorda succ!");
    b = helper_get_tscoord(env, coordb);
    D_LOG("Get coordb succ!");

    TSAlgo_CalcCenter(&a, &b, &c);
    D_LOG("Calc succ!");

    obj = helper_new_tscoord(env);
    D_LOG("New coordc succ!");
    helper_set_tscoord(env, obj, &c);
    D_LOG("Set coordc succ!");
    return obj;
}



