#include "algorithm.h"

int TSAlgo_CalcCenter(const TSCoord *a, const TSCoord *b, TSCoord *result)
{
    result->N = (a->N + b->N) / 2;
    result->E = (a->E + b->E) / 2;
    result->Z = (a->Z + b->Z) / 2;

    return TSALGO_NOERROR;
}

