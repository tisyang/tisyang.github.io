#ifndef COM_ZHDGPS_TS_TSMATH_H
#define COM_ZHDGPS_TS_TSMATH_H

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif


/* 使用安卓调试输出
 * 使用方法 D_LOG(fmt, ...)
 * 如果需要屏蔽则使用宏定义 #define D_LOG(...) 置空
 * */
#include <android/log.h>
#define D_LOG(...) ((void)__android_log_print(ANDROID_LOG_DEBUG  , "TSMath", __VA_ARGS__))


/* 动态库加载时候被调用的方法，可以进行一些初始化操作 */
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved);


/* --------------------------------------------------- */
/* Native 导出函数组 */
/* 对应 TSMath.getVersion */
JNIEXPORT jstring JNICALL native_get_version(JNIEnv *env, jobject thiz);
/* 对应 TSMath.calcCenter */
JNIEXPORT jobject JNICALL native_calc_center(JNIEnv *env, jobject thiz, jobject coorda, jobject coordb);

#ifdef __cplusplus
}
#endif

#endif
