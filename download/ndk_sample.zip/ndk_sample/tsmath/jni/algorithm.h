#ifndef TS_ALGORITHM_H
#define TS_ALGORITHM_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _TSCoord {
    double N;
    double E;
    double Z;
}TSCoord;

enum TSAlgo_ErrorCode {
    TSALGO_NOERROR,
};

int TSAlgo_CalcCenter(const TSCoord *a, const TSCoord *b, TSCoord *result);

#ifdef __cplusplus
}
#endif

#endif
