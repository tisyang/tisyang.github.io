编译
----

在当前目录下使用命令 ndk-build，编译好的so文件在libs目录下。

obj 目录是构建生成的临时目录。

TSCoord.java 和 TSMath.java 是java层接口文件。
