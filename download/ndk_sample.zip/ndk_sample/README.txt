README
======

tsmath为so库源文件包。

NDKDemo为使用so库的Android项目Demo。
