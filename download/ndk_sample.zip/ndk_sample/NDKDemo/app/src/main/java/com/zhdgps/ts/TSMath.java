package com.zhdgps.ts;

public class TSMath {
	static {
		System.loadLibrary("tsmath");
	}

	public static native String getVersion();
	/* 计算两点连线中心点 */
	public static native TSCoord calcCenter(TSCoord a, TSCoord b);
}

