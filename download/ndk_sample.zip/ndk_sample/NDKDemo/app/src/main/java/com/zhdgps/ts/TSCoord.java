package com.zhdgps.ts;


public class TSCoord {
	public double N;
	public double E;
	public double Z;
}
