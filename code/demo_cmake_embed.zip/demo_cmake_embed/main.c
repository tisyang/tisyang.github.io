#include <stdio.h>
#include "a_demo_assets.assets.h"

int main(int argc, char **argv)
{
    printf("a_demo_assets size=%u\n", A_DEMO_ASSETS_ASSETS__SIZE);
    printf("a_demo_assets data=\n");
    fwrite(A_DEMO_ASSETS_ASSETS__DATA, A_DEMO_ASSETS_ASSETS__SIZE, 1, stdout);
    return 0;
}
